[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=4636902&assignment_repo_type=AssignmentRepo)
# Chapter 11: Collections

Please complete the following programming exercises from the textbook. You may assist your fellow students but do **NOT** share answers/code. Remember, your code may be programatically compared with the rest of the class for similarity.

- 11.2 alternate
- 11.5 sortAndRemoveDuplicates
- 11.9 hasOdd
- 11.16 is1to1

Extra Credit: Project 11.2 stableMarriage

Be sure to document your source code and update this README. Your submission must pass the tests in the provided tester program. You may make small alterations to the tester if your class/methods are named different than what the tester expects. However, your code should not be dependent on any particular implementation of an ADT. Please contact me if you need assistance.
