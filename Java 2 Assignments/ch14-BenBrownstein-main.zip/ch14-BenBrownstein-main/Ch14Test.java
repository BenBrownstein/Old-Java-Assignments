import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.util.*;
import java.lang.*;
/**
 * JUnit Tests for Chapter 14
 */
@SuppressWarnings("deprecation")
public class Ch14Test {
	/**
	 * Base Stacks and Queues
	 */
	static Queue<Integer> emptyQueue, singleQueue, palindrome, notPalindrome;
	static Stack<Integer> emptyStack, singleStack, sortedStack, notSortedStack, 
						equalStack, minStack, minRemovedStack, minRemovedStack2;
	/**
	 * Reset the base data structures just in case
	 */
	@BeforeEach 
	void reset(){
		emptyQueue = new LinkedList<Integer>();
		singleQueue = new LinkedList<Integer>(List.of(1));
		palindrome = new LinkedList<Integer>(List.of(3, 8, 17, 9, 17, 8, 3));
		notPalindrome = new LinkedList<Integer>(List.of(3, 17, 9, 4, 17, 3));
		
		emptyStack = new Stack<Integer>();
		singleStack = new Stack<Integer>();singleStack.push(1);
		sortedStack = new Stack<Integer>();
		equalStack = new Stack<Integer>();
		notSortedStack = new Stack<Integer>();notSortedStack.push(1);
		List<Integer> sortedList = List.of(20, 20, 17, 11, 8, 8, 3, 2);
		for(int i: sortedList){
			sortedStack.push(i);notSortedStack.push(i);equalStack.push(i);
		}
		
		List<Integer> minList = List.of(2, 8, 3, 19, 2, 3, 2, 7, 12, -8, 4);
		minStack = new Stack<Integer>();
		minRemovedStack = new Stack<Integer>();
		minRemovedStack2 = new Stack<Integer>();
		for(int i: minList){
			minStack.push(i);minRemovedStack.push(i);minRemovedStack2.push(i);
			if(i == -8){
				minRemovedStack.pop();
				minRemovedStack2.pop();
			} else if(i == 2){
				minRemovedStack2.pop();
			}
		}		
		return;
	}
	
	/**
	 * Tests 14.5 equals
	 */
	@Test 
	public void testEquals(){
		assertTrue(equals(sortedStack, equalStack));
		assertFalse(equals(sortedStack, minStack));
		assertEquals(sortedStack, equalStack);//ensure sorted is "unchanged"
		assertFalse(equals(emptyStack, singleStack));
		assertFalse(equals(null, emptyStack));
		assertTrue(equals(null,null));
	}
	
	/**
	 * Tests 14.8 isPalindrome
	 */
	@Test 
	public void testIsPalindrome(){
		assertTrue(isPalindrome(emptyQueue));
		assertTrue(isPalindrome(palindrome));
		assertTrue(isPalindrome(palindrome));//ensure palindrome is "unchanged"
		assertNotEquals(emptyQueue, palindrome);
		assertTrue(isPalindrome(singleQueue));
		assertFalse(isPalindrome(notPalindrome));
		assertThrows(IllegalArgumentException.class, ()->{isPalindrome(null);});
	}
	
	/**
	 * Tests 14.15 isSorted
	 */
	@Test 
	public void testIsSorted(){
		assertTrue(isSorted(sortedStack));
		assertEquals(sortedStack, equalStack);//ensure sortedStack is "unchanged"
		assertFalse(isSorted(notSortedStack));
		assertTrue(isSorted(emptyStack));
		assertTrue(isSorted(singleStack));
		assertThrows(IllegalArgumentException.class, ()->{isSorted(null);});
	}
	
	/**
	 * Tests 14.19 removeMin
	 */
	@Test 
	public void testRemoveMin(){
		assertEquals(-8, removeMin(minStack));
		assertEquals(minStack, minRemovedStack);
		assertEquals(2, removeMin(minStack));
		assertEquals(minStack, minRemovedStack2);
		assertThrows(IllegalArgumentException.class, ()->{removeMin(null);});
		assertThrows(IllegalArgumentException.class, ()->{removeMin(emptyStack);});
	}

	/**
	 * Checks if two stacks of Integers have the same sequence of Integers.
	 * 
	 * You can use one stack as auxillary storage. Both stacks should look 
	 * as they did before the method was called.
	 * 
	 * @param s1 The first stack
	 * @param s2 The second stack
	 * @return true if the stacks have the same sequence
	 */
	public static boolean equals(Stack<Integer> s1, Stack<Integer> s2){
		return true;
	}
	
	/**
	 * Checks if a queue of Integers has the same sequence forwards and backwards.
	 * 
	 * Use one stack as auxilary storage. The queue needs to look as 
	 * it did prior to this function call after it returns.
	 * 
	 * @param q The candidate palindrome
	 * @return true if the queue is a palindrome
	 * @throws IllegalArgumentException if the queue is null
	 */
	public static boolean isPalindrome(Queue<Integer> q){
		return true;
	}
	/**
	 * Checks if a stack of Integers is sorted
	 * 
	 * Use one queue or stack, but not both, as auxilary storage. 
	 * The stack needs to look as it did prior to this function call after it returns.
	 * 
	 * @param s The candidate sorted stack
	 * @return true if the stack is sorted
	 * @throws IllegalArgumentException if the stack is null
	 */
	public static boolean isSorted(Stack<Integer> s){
		return true;
	}
	
	/**
	 * Removes the minimum value from a stack.
	 * 
	 * Use one queue as auxilary storage. 
	 * The stack needs to maintain relative ordering sans min(s).
	 * 
	 * @param s The stack to have elements removed
	 * @return true if the stack is sorted
	 * @throws IllegalArgumentException if the stack is null or empty
	 */
	public static int removeMin(Stack<Integer> s){
		return 0;
	}
}
