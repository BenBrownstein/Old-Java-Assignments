[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=4741951&assignment_repo_type=AssignmentRepo)
# Chapter 14: Stacks and Queues

Please complete the following programming exercises. You may assist your fellow students but do **NOT** share answers/code.

- 14.5 equals
- 14.8 isPalindrome
- 14.15 isSorted
- 14.19 removeMin

This repo contains JUnit test cases and a current JUnit java archive. You may add additional test cases. Your code must pass all the JUnit test cases. 
If you are using an IDE other than Geany, you must ensure that your code still passes all when run via GitHub Actions.

Be sure to document your source code with Javadoc and update this README. Please contact me if you need assistance.
