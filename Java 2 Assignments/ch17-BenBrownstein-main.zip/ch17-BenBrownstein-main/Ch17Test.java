import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.util.*;
import java.lang.*;
/**
 * JUnit Tests for Chapter 17
 */

public class Ch17Test {

	/**
	 * Reset the base data structures just in case
	 */
	@BeforeEach 
	void reset(){
		return;
	}
	
	/**
	 * An empty JUnit test case
	 */
	@Test 
	public void testExample(){		
		assertTrue(true);
	}
}
