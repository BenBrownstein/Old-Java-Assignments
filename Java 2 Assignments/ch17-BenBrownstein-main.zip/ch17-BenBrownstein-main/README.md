[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=4815718&assignment_repo_type=AssignmentRepo)
# Chapter 17: Binary Trees

Complete the following using the BinarySearchTree provided. Unfortunately, 
the book uses regular Binary Trees in their example/problem references that are not valid BSTs. 
Use those references as a guide but ensure your solutions are BSTs.
You may assist your fellow students but do **NOT** share answers/code.

- 17.7 isFull
- 17.9 equals (modified to work with JUnit)
- 17.12 removeLeaves
- 17.15 trim

This repo contains a dummy JUnit test case. You need to add your own test cases to thoroughly test you code.
If you are using an IDE other than Geany, you must ensure that your code still passes when run via GitHub Actions.

Be sure to document your source code with Javadoc and update this README. Please contact me if you need assistance.
