/**
 * Class that tests Student and Student Directory. You need to fix
 * Student and StudentDirectory to pass these test cases.
 * 
 */
import java.io.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
@SuppressWarnings("unchecked")
public class CS1Test {
	
	public static void main (String[] args) {
		boolean pass = false;
		String errorMsg = "", className = "", methodName = "", paramsStr = "", fullName = "";
		
		try{
			className = "Student";
			Field[] fields = Student.class.getDeclaredFields();
			for(Field f:fields){
				if(Modifier.isPublic(f.getModifiers())){
					throw new IllegalAccessError(className+"."+f.getName());
				}
			}
			System.out.println("Field test passed.");
			
			Class params[] = new Class[0];
			methodName="Student";
			fullName = className+"."+methodName+"("+paramsStr+")";
			Constructor defaultCon = Student.class.getDeclaredConstructor(params);
			Student empty = (Student)defaultCon.newInstance();
			assert empty.getGiven()!=null && empty.getFamily()!=null &&
					empty.getGrades()!=null : "Name or Grades is null";
			System.out.println("Default constructor test passed.");
			
			params = new Class[4];params[0] = String.class;params[1]=String.class;
			params[2] = int.class;params[3] = String[].class;
			
			paramsStr = "String,String,int,String[]";
			Constructor fancyCon = Student.class.getDeclaredConstructor(params);
			String[]grades = {"100","100","100","100"};
			Student connie = (Student)fancyCon.newInstance("cOnNiE", "maHESwaran", 10, grades);
			assert connie.getGiven().equals("connie"): "Expected <connie> but was <"+connie.getGiven()+">";
			assert connie.getFamily().equals("MAHESWARAN"): "Expected <MAHESWARAN> but was <"+connie.getFamily()+">";
			grades = null;
			Student temp = (Student)fancyCon.newInstance(null, null, 0, null);
			assert temp.getGiven()!=null && temp.getFamily()!=null && temp.getGrades()!=null: "Name or Grades is null in "+methodName+"("+paramsStr+")";
			System.out.println("Fancy constructor test passed.");
			
			methodName = "getGrades";
			paramsStr = "";
			fullName = className + "." + methodName+"("+paramsStr+")";
			String[] grades2 = connie.getGrades();
			for(int i =0;i<grades2.length;i++){
				grades2[i] = "0";
			}
			assert connie.average()>=99.9 : "Someone was able to tamper with Connie's grades.";
			System.out.println("getGrades test passed.");
			
			className = "StudentDirectory";methodName = "buildDirectory";paramsStr = "String";
			fullName = className + "." + methodName+"("+paramsStr+")";
			try{
				StudentDirectory.buildDirectory(null);
			}catch(Exception e){
				String exName = e.getClass().getSimpleName();
				assert exName.equals("IllegalArgumentException"): fullName+" expected <IllegalArgumentException> but was <"+exName+">";
			}
			Student[] students = null;
			try{
				students = StudentDirectory.buildDirectory("students.txt");
				
				for(Student x:students){
					assert x != null: "null Student in directory. ";
					assert temp.getFamily().compareTo(x.getFamily()) < 0: "Students are not in order";
					temp = x;
				}
			}catch(AssertionError ae){
				throw ae;
			}catch(FileNotFoundException fnfe){
				throw fnfe;
			}catch(NoSuchElementException nsee){
				throw nsee;
			}
			System.out.println("Build directory test passed.");
			
			methodName = "printDirectory";paramsStr = "Student[]";
			fullName = className + "." + methodName+"("+paramsStr+")";
			
			try{
				StudentDirectory.printDirectory(null);
			}
			catch(Exception e){
				String exName = e.getClass().getSimpleName();
				assert exName.equals("IllegalArgumentException"): fullName+" expected <IllegalArgumentException> but was <"+exName+">";
			}
			
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PrintStream original = System.out, record = new PrintStream(baos);
			System.setOut(record);
			StudentDirectory.printDirectory(students);
			record.flush();
			System.setOut(original);
			record.close();
			try{
				String actual = baos.toString(), expected  = Files.readString(Path.of("expected.txt"));
				actual = actual.replaceAll("\\r|\\n", "");
				expected = expected.replaceAll("\\r|\\n", "");
				assert expected.equals(actual) : "Actual output doesnot match expected.";
			}catch(IOException ioe){
				throw ioe;
			}
			System.out.println("Print directory test passed.");
			pass = true;
		}catch(IllegalArgumentException iae){
			errorMsg = "Invalid argument in method "+fullName;
		}catch(NoSuchMethodException nsme){
			errorMsg = "Could not find method "+fullName;
		}catch(IllegalAccessError iae){
			errorMsg = "Field "+iae.getMessage()+" is public";
		}catch(InstantiationException ie){
			errorMsg = "Could not create instance of " + className;
		}catch(IllegalAccessException iae){
			errorMsg = "Could not call "+fullName;
		}catch(InvocationTargetException ite){
			errorMsg = "Could not call "+fullName;
		}catch(AssertionError ae){
			errorMsg = ae.getMessage();
		}catch(FileNotFoundException fnfe){
			errorMsg = "Could not find file.";
		}catch(NoSuchElementException nsee){
			errorMsg = "No such element";
		}catch(IOException ioe){
			errorMsg = "Missing expected output to compare with actual.";
		}
		System.out.println();
		if(!pass){
			System.out.println("Test failed: "+errorMsg);
			System.exit(-1);
		}
		System.out.println("All tests passed.");
	}
}
