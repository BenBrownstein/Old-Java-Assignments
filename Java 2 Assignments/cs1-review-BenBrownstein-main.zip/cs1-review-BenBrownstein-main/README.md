[![Work in Repl.it](https://classroom.github.com/assets/work-in-replit-14baed9a392b3a25080506f3b7b6d57f295ec2978f6f33ec97e36a161684cbe9.svg)](https://classroom.github.com/online_ide?assignment_repo_id=4555926&assignment_repo_type=AssignmentRepo)
# CS 1 Review

This Java program is broken. Your tasks are to:
- Fix all the runtime, logic, and security errors as idenfied in the Tester.
- Address the lack of documentation.
- Replace the contents of this `README.md`.

Remember to keep your repository clean of executable files and to make 
your README relevant for the reader. [Here](https://www.markdownguide.org/cheat-sheet/) 
is a link to a markdown cheat sheet. If you receive any help from a resource other than 
the lectures, textbook, or official Java documentation, you must cite it (person or website).
For small contributions, a comment with the link is fine. Larger contributions require 
more information.  Also, while GitHub can compile and execute
your program, it is not a replacement for your own IDE as compute time  on 
GitHub is limited. Good luck!
