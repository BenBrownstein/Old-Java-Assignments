/**
 * Representation of a Student
 * 
 * A student has a name, current year, and array of grades. Once a student 
 * has been created, it should not be changed hence the lack of setX methods.
 */
public class Student implements Comparable<Student>{
	public String givenName, familyName;
	public int year;
	public String[] grades;
	
	public Student(String givenName, String familyName, int year, String[] grades){
		this.givenName = givenName;
		this.familyName = familyName;
		this.year = year;
		this.grades = grades;
	}
	
	public String getGiven(){
		return this.givenName;
	}
	
	public String getFamily(){
		return this.familyName;
	}
	
	public int getYear(){
		return this.year;
	}
	
	public String[] getGrades(){
		return this.grades;
	}
	
	public double average(){
		double total = 0.0;
		for(int grade:grades){
			total += grade;
		}
		return total/grades.length;
	}
	
	public String toString(){
		String padding = (this.year < 10) ? " " : "";
		return this.familyName + ", " + this.givenName + "\n" +
				"Year: " + padding + this.year + "\t" + 
				"Average: " + String.format("%.2f",this.average());
	}
	
	public int compareTo(Student other){
		return this.familyName.compareTo(other.getFamily());
	}
}
