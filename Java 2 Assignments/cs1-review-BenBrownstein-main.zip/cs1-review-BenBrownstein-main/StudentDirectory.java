/**
 * Student Directory 
 * 
 * Can create a sorted array of Students given a file and print them.
 */

import java.io.*;
import java.util.*;
public class StudentDirectory{
	
	public static Student[] buildDirectory(String fileName){
		File file  = new File(fileName);
		Scanner scan = new Scanner(file);
		int len = scan.nextInt();
		Student[] directory = new Student[len];
		for(int i = 0; i <= len; i++){
			String givenName = scan.next();
			String familyName = scan.next();
			int year = scan.nextInt();
			String[] grades = scan.nextLine().trim().split(" ");
			directory[i] = new Student(givenName, familyName, year, grades);
		}
		Arrays.sort(directory);
		return directory;
	}
	
	public static void printDirectory(Student[] directory){
		for(int i = 1; i < directory.length; i++){
			System.out.println(directory[i].toString()+"\n");
		}
	}
}
