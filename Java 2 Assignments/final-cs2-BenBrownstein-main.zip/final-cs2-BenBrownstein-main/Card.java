
public class Card {
	//String which holds what type of card it is used for classes that only work for certain types of cards
	private String frame;
	
	/**
	 * Initializes class
	 */
	public Card() 
	{
		frame = null;
	}
	
	/**
	 * Setter for frame
	 * @param frame String which identifies what type of card it is
	 */
	public void setFrame(String frame) 
	{
		this.frame = frame;
	}
	
	/**
	 * Getter for frame
	 * @return the String in frame
	 */
	public String getFrame() 
	{
		return frame;
	}
	
	/**
	 * Dummy class to get overwritten by MCards, SCards, and TCards
	 * @return temp
	 */
	public String getName() 
	{
		return "temp";
	}
	
	/**
	 * Dummy class to get overwritten by MCards, SCards, and TCards
	 * @return temp
	 */
	public String getInfo() 
	{
		return "temp";
	}
	
	/**
	 * Dummy class to get overwritten by MCards
	 * If it is a spell or trap return an a message saying it does not work
	 * @return temp
	 */
	public String getBaseStats() 
	{
		if (frame != "Monster") 
		{
			return "This card does not have Stats";
		}
		
		return "temp";
	}
	
	/**
	 * Dummy class to get overwritten by MCards
	 * If it is a spell or trap return an a message saying it does not work
	 * @return temp
	 */
	public String getCurrentStats() 
	{
		if (frame != "Monster") 
		{
			return "This card does not have Stats";
		}
		
		return "temp";
	}
	
	/**
	 * Dummy class to get overwritten by SCards and TCards
	 * If it is a monster return an a message saying it does not work
	 * @return temp
	 */
	public void set() 
	{
		if (frame == "Monster") 
		{
			throw new IllegalArgumentException ("Monsters use a different method for their battle positions");
		}
	}
	
	/**
	 * Dummy class to get overwritten by SCards and TCards
	 * If it is a monster return an a message saying it does not work
	 * @return temp
	 */
	public void activate() 
	{
		if (frame == "Monster") 
		{
			throw new IllegalArgumentException ("Monsters use a different method for their battle positions");
		}
	}
	
	/**
	 * Dummy class to get overwritten by SCards and TCards
	 * If it is a monster return an a message saying it does not work
	 * @return temp
	 */
	public boolean getSet() 
	{
		if (frame == "Monster") 
		{
			throw new IllegalArgumentException ("Monsters use a different method for their battle positions");
		}
		return true;
	}
}
