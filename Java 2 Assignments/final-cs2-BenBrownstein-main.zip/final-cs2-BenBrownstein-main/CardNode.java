
	//Code taken from the Node-1 class that was created in class
	//CardNode(E data, CardNode next) was taken from the ListNode class of Chapter 14
public class CardNode {
	//Holds a Card as data MCards, SCards, and TCards all extend Card
	private Card data;
	//The node this node is pointing at
	private CardNode next;
	
	/**
	 * Initializes class
	 */
	public CardNode()
	{
		this(null);
	}
	
	/**
	 * Initializes class with data
	 * @param data a Card 
	 */
	public CardNode(Card data)
	{
		this.data = data;
		this.next = null;
	}
	
	/**
	 * Initializes class with data and what the next card is
	 * @param data a Card 
	 * @param next the CardNode that this one is point to
	 */
	public CardNode(Card data, CardNode next) 
	{
		this.data = data;
		this.next = next;
	}
	
	/**
	 * Getter for data
	 * @return the Card stored in the CardNode
	 */
	public Card getData()
	{
		return this.data;
	}
	
	/**
	 * Setter for data
	 * @param data the Card to be stored in the CardNode
	 */
	public void setData(Card data)
	{
		this.data = data;
	}
	
	/**
	 * Getter for next
	 * @return the CardNode this CardNode is pointing at
	 */
	public CardNode getNext()
	{
		return next;
	}
	
	/**
	 * Setter for next
	 * @param next a CardNode
	 */
	public void setNext(CardNode next)
	{
		this.next = next;
	}
	
}
