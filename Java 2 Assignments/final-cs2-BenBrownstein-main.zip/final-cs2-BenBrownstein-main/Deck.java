import java.util.*;
@SuppressWarnings("unchecked")
//Initial Code was taken from the NodeQueue class made in class and the Chapter 16 HW class LinkedIntList
public class Deck {
	private CardNode front, back;
	private int size;
	
	public Deck()
	{
		front = null;
		back = null;
		size = 0;
	}
	
	
	public void push (Card value) 
	{

		front = new CardNode(value, front);		
		size++;
	}
	
	public Card pop () 
	{
		if (front == null) 
		{
			throw new IllegalArgumentException("front can't be null");
		}
		Card data = front.getData();
		front = front.getNext();
		size--;
		return data;
	}
	
	public Card getFrontData() 
	{
		Card data = front.getData();
		return data;
	}
	
	public void enqueue(Card data){
		CardNode node = new CardNode(data);
		if(isEmpty()){
			front = node;
		}else{
			back.setNext(node);
		}
		back = node;
		size++;
	}

	public Card dequeue(){
		if(isEmpty()){
			throw new NoSuchElementException("Q is empty");
		}
		Card data = front.getData();
		front = front.getNext();
		size--;
		if(isEmpty()){
			back = null;
		}
		return data;
	}
	
	public void addAll(Card[]data){
		for(Card i:data){
			push(i);
		}
	}
	
	public void addAll(Deck nq)
	{
		CardNode temp = nq.front;
		while(temp != null)
		{
			push(temp.getData());
			temp = temp.getNext();
		}
	}
	
	public int size(){
		return size;
	}
	
	public boolean isEmpty(){
		return size == 0;
	}
	
	public void shuffle() 
	{
		List<Card> temp = new ArrayList<>();
		while(!isEmpty()) 
		{
			temp.add(pop());
		}
		Collections.shuffle(temp);
		while(!temp.isEmpty()) 
		{
			push(temp.get(0));
			temp.remove(0);
		}
		
	}
	
	public String toString() 
	{
		if(isEmpty()) 
		{
			return "[]";
		}
		CardNode current = front;
		String str = "[";
		while(current != null) 
		{
			str = str + current.getData().getName();
			if (current.getNext() != null) 
			{
				str = str + ", ";
			}
			current = current.getNext();
		}
		str = str + "]";
		return str;
	}
}
