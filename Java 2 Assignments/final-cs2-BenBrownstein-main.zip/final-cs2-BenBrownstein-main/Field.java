import java.util.*;
//Positioning break down 
//A ATK position
//F Facedown/Set for Monsters, Spells, and Traps
//D DEF faceup position
//S Spell card
//T Trap card
public class Field {
	//Array that holds the data of the first monster zone
	private MCards mz1[];
	//Array that  holds the data of the second monster zone 
	private MCards mz2[];
	//Array that  holds the data of the third monster zone 
	private MCards mz3[];
	//Array that  holds the data of the fourth monster zone 
	private MCards mz4[];
	//Array that  holds the data of the fifth monster zone
	private MCards mz5[];
	//String that shows if the first monster zone if full and what position the card in it is in
	private String mz1s;
	//String that shows if the second monster zone if full and what position the card in it is in
	private String mz2s;
	//String that shows if the third monster zone if full and what position the card in it is in
	private String mz3s;
	//String that shows if the fourth monster zone if full and what position the card in it is in
	private String mz4s;
	//String that shows if the fifth monster zone if full and what position the card in it is in
	private String mz5s;
	//Array that holds the data of the field spell zone
	private SCards fz[];
	//String that shows if the field spell zone if full and what position the card in it is in
	private String fzs;
	//Array that holds the data of the first spell and trap zone
	private Card stz1[];
	//String that shows if the first spell and trap zone if full and what position the card in it is in
	private String stz1s;
	//Array that holds the data of the second spell and trap zone
	private Card stz2[];
	//String that shows if the second spell and trap zone if full and what position the card in it is in
	private String stz2s;
	//Array that holds the data of the third spell and trap zone
	private Card stz3[];
	//String that shows if the third spell and trap zone if full and what position the card in it is in
	private String stz3s;
	//Array that holds the data of the fourth spell and trap zone
	private Card stz4[];
	//String that shows if the fourth spell and trap zone if full and what position the card in it is in
	private String stz4s;
	//Array that holds the data of the fifth spell and trap zone
	private Card stz5[];
	//String that shows if the fifth spell and trap zone if full and what position the card in it is in
	private String stz5s;

	/**
	 * Initializing the field
	 */
	public Field() 
	{
		mz1 = new MCards [1];
		mz2 = new MCards [1];
		mz3 = new MCards [1];
		mz4 = new MCards [1];
		mz5 = new MCards [1];
		fz = new SCards [1];
		stz1 = new Card [1];
		stz2 = new Card [1];
		stz3 = new Card [1];
		stz4 = new Card [1];
		stz5 = new Card [1];
		mz1s = " ";
		mz2s = " ";
		mz3s = " ";
		mz4s = " ";
		mz5s = " ";
		fzs = " ";
		stz1s = " ";
		stz2s = " ";
		stz3s = " ";
		stz4s = " ";
		stz5s = " ";

	}
	
	/**
	 * Prints the fields layout, which zones have cards in them, and what position each card in full zones are in
	 * @return the field
	 */
	public String getField() 
	{
		String r1 = "[" + fzs + "] "+"[" + mz1s + "] "+"[" + mz2s + "] "+"[" + mz3s + "] "+"[" + mz4s + "] "+"[" + mz5s + "] "+"[" + "G" + "] ";
		String r2 = "    "+"[" + stz1s + "] "+"[" + stz2s + "] "+"[" + stz3s + "] "+"[" + stz4s + "] "+"[" + stz5s + "] "+"[" + "D" + "] ";
		String field = r1 + "\n" + r2;
		return field;
	}
	
	/**
	 * Summons a monster to the first monster zone
	 * @param monster the monster to be summoned
	 */
	public void summonMZ1(MCards monster) 
	{
		if (mz1[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz1[0] = monster;
		mz1[0].setPosition(1);
		mz1s = "A";
	}
	
	/**
	 * Sets a monster in face down defense position in the first monster zone
	 * @param monster the monster to be summoned
	 */
	public void setMZ1(MCards monster) 
	{
		if (mz1[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz1[0] = monster;
		mz1[0].setPosition(2);
		mz1s = "F";
	}
	
	/**
	 * Changes the monster in the first monster zone to ATK mode
	 */
	public void toATKMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz1[0].getPosition() == "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is already in ATK Mode");
		}
		mz1[0].setPosition(1);
		mz1s = "A";
	}
	
	/**
	 * Flips face up the monster in the first monster zone from face down DEF position it is still in DEF position
	 */
	public void flipMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz1[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is not in facedown defense position");
		}
		mz1[0].setPosition(3);
		mz1s = "D";
	}
	
	/**
	 * Changes the monster in the first monster zone from ATK position monster to DEF position
	 */
	public void toDEFMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz1[0].getPosition() != "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz1[0].setPosition(3);
		mz1s = "D";
	}
	
	/**
	 * Changes the monster in the first monster zone from face down DEF position monster into a ATK position monster
	 */
	public void flipSummonMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz1[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz1[0].setPosition(1);
		mz1s = "A";
	}
	
	/**
	 * Removes the monster from the first monster zone
	 * @return the removed monster so it can be added to the Graveyard
	 */
	public MCards destroyMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		MCards temp = mz1[0];
		mz1[0] = null;
		mz1s = " ";
		return temp;
		
	}
	
	/**
	 * Gets the info of the monster card in the first monster zone
	 * @return the info of the card
	 */
	public String getInfoMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz1[0].getInfo();
	}
	
	/**
	 * Gets the base stats of the monster in the first monster zone
	 * @return the base stats of the monster in the first monster zone
	 */
	public String getBaseStatsMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz1[0].getBaseStats();
	}
	
	/**
	 * Gets the current stats of the monster in the first monster zone
	 * @return the current stats of the monster in the first monster zone
	 */
	public String getCurrentStatsMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz1[0].getCurrentStats();
	}
	
	/**
	 * Gets the card text of the monster in the first monster zone
	 * @return the text of the monster in the first monster zone
	 */
	public String getCTextMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz1[0].getCText();
	}
	
	/**
	 * Gets the effect usage of the monster in the first monster zone
	 * @return The effect usage text of the monster in the first monster zone
	 */
	public String getEffectUsageMZ1() 
	{
		if (mz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz1[0].getEffectUsage();
	}
	
	/**
	 * Summons a monster to the second monster zone
	 * @param monster the monster to be summoned
	 */
	public void summonMZ2(MCards monster) 
	{
		if (mz2[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz2[0] = monster;
		mz2[0].setPosition(1);
		mz2s = "A";
	}
	
	/**
	 * Sets a monster in face down defense position in the second monster zone
	 * @param monster the monster to be summoned
	 */
	public void setMZ2(MCards monster) 
	{
		if (mz2[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz2[0] = monster;
		mz2[0].setPosition(2);
		mz2s = "F";
	}
	
	/**
	 * Changes the monster in the second monster zone to ATK mode
	 */
	public void toATKMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz2[0].getPosition() == "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is already in ATK Mode");
		}
		mz2[0].setPosition(1);
		mz2s = "A";
	}
	
	/**
	 * Flips face up the monster in the second monster zone from face down DEF position it is still in DEF position
	 */
	public void flipMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz2[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is not in facedown defense position");
		}
		mz2[0].setPosition(3);
		mz2s = "D";
	}
	
	/**
	 * Changes the monster in the second monster zone from ATK position monster to DEF position
	 */
	public void toDEFMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz2[0].getPosition() != "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz2[0].setPosition(3);
		mz2s = "D";
	}
	
	/**
	 * Changes the monster in the second monster zone from face down DEF position monster into a ATK position monster
	 */
	public void flipSummonMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz2[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz2[0].setPosition(1);
		mz2s = "A";
	}
	
	/**
	 * Changes the monster in the second monster zone from face down DEF position monster into a ATK position monster
	 */
	public MCards destroyMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		MCards temp = mz2[0];
		mz2[0] = null;
		mz2s = " ";
		return temp;
		
	}
	
	/**
	 * Gets the info of the monster card in the second monster zone
	 * @return the info of the card
	 */
	public String getInfoMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz2[0].getInfo();
	
	}
	
	/**
	 * Gets the base stats of the monster in the second monster zone
	 * @return the base stats of the monster in the second monster zone
	 */
	public String getBaseStatsMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz2[0].getBaseStats();
	}
	
	/**
	 * Gets the current stats of the monster in the second monster zone
	 * @return the current stats of the monster in the second monster zone
	 */
	public String getCurrentStatsMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz2[0].getCurrentStats();
	}
	
	/**
	 * Gets the card text of the monster in the second monster zone
	 * @return the text of the monster in the second monster zone
	 */
	public String getCTextMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz2[0].getCText();
	}
	
	/**
	 * Gets the effect usage of the monster in the second monster zone
	 * @return The effect usage text of the monster in the second monster zone
	 */
	public String getEffectUsageMZ2() 
	{
		if (mz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz2[0].getEffectUsage();
	}
	
	/**
	 * Summons a monster to the third monster zone
	 * @param monster the monster to be summoned
	 */
	public void summonMZ3(MCards monster) 
	{
		if (mz3[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz3[0] = monster;
		mz3[0].setPosition(1);
		mz3s = "A";
	}
	
	/**
	 * Sets a monster in face down defense position in the third monster zone
	 * @param monster the monster to be summoned
	 */
	public void setMZ3(MCards monster) 
	{
		if (mz3[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz3[0] = monster;
		mz3[0].setPosition(2);
		mz3s = "F";
	}
	
	/**
	 * Changes the monster in the third monster zone to ATK mode
	 */
	public void toATKMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz3[0].getPosition() == "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is already in ATK Mode");
		}
		mz3[0].setPosition(1);
		mz3s = "A";
	}
	
	/**
	 * Flips face up the monster in the third monster zone from face down DEF position it is still in DEF position
	 */
	public void flipMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz3[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is not in facedown defense position");
		}
		mz3[0].setPosition(3);
		mz3s = "D";
	}
	
	/**
	 * Changes the monster in the third monster zone from ATK position monster to DEF position
	 */
	public void toDEFMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz3[0].getPosition() != "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz3[0].setPosition(3);
		mz3s = "D";
	}
	
	/**
	 * Changes the monster in the third monster zone from face down DEF position monster into a ATK position monster
	 */
	public void flipSummonMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz3[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz3[0].setPosition(1);
		mz3s = "A";
	}
	
	/**
	 * Changes the monster in the third monster zone from face down DEF position monster into a ATK position monster
	 */
	public MCards destroyMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		MCards temp = mz3[0];
		mz3[0] = null;
		mz3s = " ";
		return temp;
		
	}
	
	/**
	 * Gets the info of the monster card in the third monster zone
	 * @return the info of the card
	 */
	public String getInfoMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz3[0].getInfo();
	
	}
	
	/**
	 * Gets the base stats of the monster in the third monster zone
	 * @return the base stats of the monster in the third monster zone
	 */
	public String getBaseStatsMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz3[0].getBaseStats();
	}
	
	/**
	 * Gets the current stats of the monster in the third monster zone
	 * @return the current stats of the monster in the third monster zone
	 */
	public String getCurrentStatsMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz3[0].getCurrentStats();
	}
	
	/**
	 * Gets the card text of the monster in the third monster zone
	 * @return the text of the monster in the third monster zone
	 */
	public String getCTextMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz3[0].getCText();
	}
	
	/**
	 * Gets the effect usage of the monster in the third monster zone
	 * @return The effect usage text of the monster in the third monster zone
	 */
	public String getEffectUsageMZ3() 
	{
		if (mz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz3[0].getEffectUsage();
	}
	
	/**
	 * Summons a monster to the fourth monster zone
	 * @param monster the monster to be summoned
	 */
	public void summonMZ4(MCards monster) 
	{
		if (mz4[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz4[0] = monster;
		mz4[0].setPosition(1);
		mz4s = "A";
	}
	
	/**
	 * Sets a monster in face down defense position in the fourth monster zone
	 * @param monster the monster to be summoned
	 */
	public void setMZ4(MCards monster) 
	{
		if (mz4[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz4[0] = monster;
		mz4[0].setPosition(2);
		mz4s = "F";
	}
	
	/**
	 * Changes the monster in the fourth monster zone to ATK mode
	 */
	public void toATKMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz4[0].getPosition() == "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is already in ATK Mode");
		}
		mz4[0].setPosition(1);
		mz4s = "A";
	}
	
	/**
	 * Flips face up the monster in the fourth monster zone from face down DEF position it is still in DEF position
	 */
	public void flipMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz4[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is not in facedown defense position");
		}
		mz4[0].setPosition(3);
		mz4s = "D";
	}
	
	/**
	 * Changes the monster in the fourth monster zone from ATK position monster to DEF position
	 */
	public void toDEFMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz4[0].getPosition() != "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz4[0].setPosition(3);
		mz4s = "D";
	}
	
	/**
	 * Changes the monster in the fourth monster zone from face down DEF position monster into a ATK position monster
	 */
	public void flipSummonMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz4[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz4[0].setPosition(1);
		mz4s = "A";
	}
	
	/**
	 * Changes the monster in the fourth monster zone from face down DEF position monster into a ATK position monster
	 */
	public MCards destroyMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		MCards temp = mz4[0];
		mz4[0] = null;
		mz4s = " ";
		return temp;
		
	}
	
	/**
	 * Gets the info of the monster card in the fourth monster zone
	 * @return the info of the card
	 */
	public String getInfoMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz4[0].getInfo();
	
	}
	
	/**
	 * Gets the base stats of the monster in the fourth monster zone
	 * @return the base stats of the monster in the fourth monster zone
	 */
	public String getBaseStatsMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz4[0].getBaseStats();
	}
	
	/**
	 * Gets the current stats of the monster in the fourth monster zone
	 * @return the current stats of the monster in the fourth monster zone
	 */
	public String getCurrentStatsMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz4[0].getCurrentStats();
	}
	
	/**
	 * Gets the card text of the monster in the fourth monster zone
	 * @return the text of the monster in the fourth monster zone
	 */
	public String getCTextMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz4[0].getCText();
	}
	
	/**
	 * Gets the effect usage of the monster in the fourth monster zone
	 * @return The effect usage text of the monster in the fourth monster zone
	 */
	public String getEffectUsageMZ4() 
	{
		if (mz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz4[0].getEffectUsage();
	}
	
	/**
	 * Summons a monster to the fifth monster zone
	 * @param monster the monster to be summoned
	 */
	public void summonMZ5(MCards monster) 
	{
		if (mz5[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz5[0] = monster;
		mz5[0].setPosition(1);
		mz5s = "A";
	}
	
	/**
	 * Sets a monster in face down defense position in the fifth monster zone
	 * @param monster the monster to be summoned
	 */
	public void setMZ5(MCards monster) 
	{
		if (mz5[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a monster in that zone");
		}
		mz5[0] = monster;
		mz5[0].setPosition(2);
		mz5s = "F";
	}
	
	/**
	 * Changes the monster in the fifth monster zone to ATK mode
	 */
	public void toATKMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz5[0].getPosition() == "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is already in ATK Mode");
		}
		mz5[0].setPosition(1);
		mz5s = "A";
	}
	
	/**
	 * Flips face up the monster in the fifth monster zone from face down DEF position it is still in DEF position
	 */
	public void flipMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz5[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is not in facedown defense position");
		}
		mz5[0].setPosition(3);
		mz5s = "D";
	}
	
	/**
	 * Changes the monster in the fifth monster zone from ATK position monster to DEF position
	 */
	public void toDEFMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz5[0].getPosition() != "ATK mode") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz5[0].setPosition(3);
		mz5s = "D";
	}
	
	/**
	 * Changes the monster in the fifth monster zone from face down DEF position monster into a ATK position monster
	 */
	public void flipSummonMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		if(mz5[0].getPosition() != "Set") 
		{
			throw new IllegalArgumentException ("This card is is already in DEF mode");
		}
		mz5[0].setPosition(1);
		mz5s = "A";
	}
	/**
	 * Changes the monster in the fifth monster zone from face down DEF position monster into a ATK position monster
	 */
	public MCards destroyMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		MCards temp = mz5[0];
		mz5[0] = null;
		mz5s = " ";
		return temp;
		
	}
	
	/**
	 * Gets the info of the monster card in the fifth monster zone
	 * @return the info of the card
	 */
	public String getInfoMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz5[0].getInfo();
	
	}
	
	/**
	 * Gets the base stats of the monster in the fifth monster zone
	 * @return the base stats of the monster in the fifth monster zone
	 */
	public String getBaseStatsMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz5[0].getBaseStats();
	}
	
	/**
	 * Gets the current stats of the monster in the fifth monster zone
	 * @return the current stats of the monster in the fifth monster zone
	 */
	public String getCurrentStatsMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz5[0].getCurrentStats();
	}
	
	/**
	 * Gets the card text of the monster in the fifth monster zone
	 * @return the text of the monster in the fifth monster zone
	 */
	public String getCTextMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz5[0].getCText();
	}
	
	/**
	 * Gets the effect usage of the monster in the fifth monster zone
	 * @return The effect usage text of the monster in the fifth monster zone
	 */
	public String getEffectUsageMZ5() 
	{
		if (mz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no monster in that zone");
		}
		return mz5[0].getEffectUsage();
	}
	
	/**
	 * Sets a field spell card in the field spell zone
	 * @param spell field spell to be set in the field spell zone
	 */
	public void setFZ (SCards spell) 
	{
		if (spell.getSubType() != "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		if (fz[0] != null) 
		{
			destroyFZ();
		}
		fz[0] = spell;
		fz[0].set();
		fzs = "F";
	}
	
	/**
	 * Places and activates a field spell in the field spell zone
	 * @param spell the field spell to be activated
	 */
	public void activateFZ (SCards spell) 
	{
		if (spell.getSubType() != "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		if (fz[0] != null) 
		{
			destroyFZ();
		}
		fz[0] = spell;
		fzs = "S";
	}
	
	/**
	 * Activates a set field spell in the field spell zone
	 */
	public void activateSetFZ() 
	{
		if (fz[0] == null) 
		{
			throw new IllegalArgumentException ("There is no field spell in the field zone");
		}
		fz[0].activate();
		fzs = "S";
	}
	
	/**
	 * Destroys the field spell in the field spell zone
	 * @return returns the destroyed spell so it can be sent to the graveyard
	 */
	public SCards destroyFZ () 
	{
		if (fz[0] == null) 
		{
			throw new IllegalArgumentException ("There is no field spell in the field zone");
		}
		SCards temp = fz[0];
		fz[0] = null;
		fzs = " ";
		return temp;
	}
	
	/**
	 * Gets the info of the field spell in the field spell zone
	 * @return the info of the field spell card in the field spell zone
	 */
	public String getInfoFZ() 
	{
		if (fz[0] == null) 
		{
			throw new IllegalArgumentException ("There is no field spell in the field zone");
		}
		return fz[0].getInfo();
	}
	
	/**
	 * Sets a card in the first spell and trap zone
	 * @param spell a spell card to be set into the zone
	 */
	public void setSTZ1(SCards spell) 
	{
		if (stz1[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		if (spell.getSubType() == "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		stz1[0] = spell;
		stz1[0].set();
		stz1s = "F";
	}
	
	/**
	 * Sets a card in the first spell and trap zone
	 * @param trap a trap card to be set into the zone
	 */
	public void setSTZ1(TCards trap) 
	{
		if (stz1[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz1[0] = trap;
		stz1[0].set();
		stz1s = "F";
	}
	
	/**
	 * Activates a spell card in the first spell and trap zone
	 * @param spell spell to be activated
	 */
	public void activateSTZ1(SCards spell) 
	{
		if (stz1[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz1[0] = spell;
		stz1[0].activate();
		stz1s = "S";
	}
	
	/**
	 * Destroys the card in the first spell and trap zone
	 * @return the destroyed card
	 */
	public Card destroySTZ1() 
	{
		if (stz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		Card temp = stz1[0];
		stz1[0] = null;
		stz1s = " ";
		return temp;
	}
	
	/**
	 * Activates the set card in the first spell and trap zone
	 */
	public void activateSetSTZ1() 
	{
		if (stz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		if (stz1[0].getSet() == false) 
		{
			throw new IllegalArgumentException ("The card in this zone is already faceup");
		}
		stz1[0].activate();
		if (stz1[0].getFrame() == "Spell") 
		{
			stz1s = "S";
		}
		if (stz1[0].getFrame() == "Trap") 
		{
			stz1s = "T";
		}
	}
	
	/**
	 * Gets the info of the card in the first spell and trap zone
	 * @return the info of the card
	 */
	public String getInfoSTZ1() 
	{
		if (stz1[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		return stz1[0].getInfo();
	}
	
	/**
	 * Sets a card in the second spell and trap zone
	 * @param spell a spell card to be set into the zone
	 */
	public void setSTZ2(SCards spell) 
	{
		if (stz2[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		if (spell.getSubType() == "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		stz2[0] = spell;
		stz2[0].set();
		stz2s = "F";
	}
	
	/**
	 * Sets a card in the second spell and trap zone
	 * @param trap a trap card to be set into the zone
	 */
	public void setSTZ2(TCards trap) 
	{
		if (stz2[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz2[0] = trap;
		stz2[0].set();
		stz2s = "F";
	}
	
	/**
	 * Activates a spell card in the second spell and trap zone
	 * @param spell spell to be activated
	 */
	public void activateSTZ2(SCards spell) 
	{
		if (stz2[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz2[0] = spell;
		stz2[0].activate();
		stz2s = "S";
	}
	
	/**
	 * Destroys the card in the second spell and trap zone
	 * @return the destroyed card
	 */
	public Card destroySTZ2() 
	{
		if (stz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		Card temp = stz2[0];
		stz2[0] = null;
		stz2s = " ";
		return temp;
	}
	
	/**
	 * Activates the set card in the second spell and trap zone
	 */
	public void activateSetSTZ2() 
	{
		if (stz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		if (stz2[0].getSet() == false) 
		{
			throw new IllegalArgumentException ("The card in this zone is already faceup");
		}
		stz2[0].activate();
		if (stz2[0].getFrame() == "Spell") 
		{
			stz2s = "S";
		}
		if (stz2[0].getFrame() == "Trap") 
		{
			stz2s = "T";
		}
	}
	
	/**
	 * Gets the info of the card in the second spell and trap zone
	 * @return the info of the card
	 */
	public String getInfoSTZ2() 
	{
		if (stz2[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		return stz2[0].getInfo();
	}
	
	/**
	 * Sets a card in the third spell and trap zone
	 * @param spell a spell card to be set into the zone
	 */
	public void setSTZ3(SCards spell) 
	{
		if (stz3[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		if (spell.getSubType() == "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		stz3[0] = spell;
		stz3[0].set();
		stz3s = "F";
	}
	
	/**
	 * Sets a card in the third spell and trap zone
	 * @param trap a trap card to be set into the zone
	 */
	public void setSTZ3(TCards trap) 
	{
		if (stz3[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz3[0] = trap;
		stz3[0].set();
		stz3s = "F";
	}
	
	/**
	 * Activates a spell card in the third spell and trap zone
	 * @param spell spell to be activated
	 */
	public void activateSTZ3(SCards spell) 
	{
		if (stz3[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz3[0] = spell;
		stz3[0].activate();
		stz3s = "S";
	}
	
	/**
	 * Destroys the card in the third spell and trap zone
	 * @return the destroyed card
	 */
	public Card destroySTZ3() 
	{
		if (stz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		Card temp = stz3[0];
		stz3[0] = null;
		stz3s = " ";
		return temp;
	}
	
	/**
	 * Activates the set card in the third spell and trap zone
	 */
	public void activateSetSTZ3() 
	{
		if (stz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		if (stz3[0].getSet() == false) 
		{
			throw new IllegalArgumentException ("The card in this zone is already faceup");
		}
		stz3[0].activate();
		if (stz3[0].getFrame() == "Spell") 
		{
			stz3s = "S";
		}
		if (stz3[0].getFrame() == "Trap") 
		{
			stz3s = "T";
		}
	}
	
	/**
	 * Gets the info of the card in the third spell and trap zone
	 * @return the info of the card
	 */
	public String getInfoSTZ3() 
	{
		if (stz3[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		return stz3[0].getInfo();
	}
	
	/**
	 * Sets a card in the fourth spell and trap zone
	 * @param spell a spell card to be set into the zone
	 */
	public void setSTZ4(SCards spell) 
	{
		if (stz4[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		if (spell.getSubType() == "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		stz4[0] = spell;
		stz4[0].set();
		stz4s = "F";
	}
	
	/**
	 * Sets a card in the fourth spell and trap zone
	 * @param trap a trap card to be set into the zone
	 */
	public void setSTZ4(TCards trap) 
	{
		if (stz4[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz4[0] = trap;
		stz4[0].set();
		stz4s = "F";
	}
	
	/**
	 * Activates a spell card in the fourth spell and trap zone
	 * @param spell spell to be activated
	 */
	public void activateSTZ4(SCards spell) 
	{
		if (stz4[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz4[0] = spell;
		stz4[0].activate();
		stz4s = "S";
	}
	
	/**
	 * Destroys the card in the fourth spell and trap zone
	 * @return the destroyed card
	 */
	public Card destroySTZ4() 
	{
		if (stz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		Card temp = stz4[0];
		stz4[0] = null;
		stz4s = " ";
		return temp;
	}
	
	/**
	 * Activates the set card in the fourth spell and trap zone
	 */
	public void activateSetSTZ4() 
	{
		if (stz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		if (stz4[0].getSet() == false) 
		{
			throw new IllegalArgumentException ("The card in this zone is already faceup");
		}
		stz4[0].activate();
		if (stz4[0].getFrame() == "Spell") 
		{
			stz4s = "S";
		}
		if (stz4[0].getFrame() == "Trap") 
		{
			stz4s = "T";
		}
	}
	
	/**
	 * Gets the info of the card in the fourth spell and trap zone
	 * @return the info of the card
	 */
	public String getInfoSTZ4() 
	{
		if (stz4[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		return stz4[0].getInfo();
	}
	
	/**
	 * Sets a card in the fifth spell and trap zone
	 * @param spell a spell card to be set into the zone
	 */
	public void setSTZ5(SCards spell) 
	{
		if (stz5[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		if (spell.getSubType() == "Field") 
		{
			throw new IllegalArgumentException ("You can only play field spells in the field zone");
		}
		stz5[0] = spell;
		stz5[0].set();
		stz5s = "F";
	}
	
	/**
	 * Sets a card in the fifth spell and trap zone
	 * @param trap a trap card to be set into the zone
	 */
	public void setSTZ5(TCards trap) 
	{
		if (stz5[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz5[0] = trap;
		stz5[0].set();
		stz5s = "F";
	}
	
	/**
	 * Activates a spell card in the fifth spell and trap zone
	 * @param spell spell to be activated
	 */
	public void activateSTZ5(SCards spell) 
	{
		if (stz5[0] != null) 
		{
			throw new IllegalArgumentException ("There is already a card in that zone");
		}
		stz5[0] = spell;
		stz5[0].activate();
		stz5s = "S";
	}
	
	/**
	 * Destroys the card in the fifth spell and trap zone
	 * @return the destroyed card
	 */
	public Card destroySTZ5() 
	{
		if (stz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		Card temp = stz5[0];
		stz5[0] = null;
		stz5s = " ";
		return temp;
	}
	
	/**
	 * Activates the set card in the fifth spell and trap zone
	 */
	public void activateSetSTZ5() 
	{
		if (stz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		if (stz5[0].getSet() == false) 
		{
			throw new IllegalArgumentException ("The card in this zone is already faceup");
		}
		stz5[0].activate();
		if (stz5[0].getFrame() == "Spell") 
		{
			stz5s = "S";
		}
		if (stz5[0].getFrame() == "Trap") 
		{
			stz5s = "T";
		}
	}
	
	/**
	 * Gets the info of the card in the fifth spell and trap zone
	 * @return the info of the card
	 */
	public String getInfoSTZ5() 
	{
		if (stz5[0] == null) 
		{
			throw new IllegalArgumentException ("There is no card in that zone");
		}
		return stz5[0].getInfo();
	}
}
