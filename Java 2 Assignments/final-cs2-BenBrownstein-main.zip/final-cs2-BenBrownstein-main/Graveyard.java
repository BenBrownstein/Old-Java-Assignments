import java.util.*;

//Technically has the push function of a stack as cards are added to the top from what the user can see as both the remove and to string use reverse ordering 
public class Graveyard {
	//An ArrayList of Card objects which everything is stored in but the index is reversed
	private List<Card> GY;
	//Keeping track of the back index of the list
	private int back;
	
	/**
	 * Initializes the class
	 */
	public Graveyard()
	{
		GY = new ArrayList<>();
		back = 0;
	}
	
	/**
	 * Adds a card to the top of the GY by adding it to the back of the list and increasing the back value
	 * @param card the card being added to GY
	 */
	public void add (Card card) 
	{
		GY.add(card);
		back++;
	}
	
	/**
	 * Removes a card from GY at an index
	 * The index is subtracted from back as the list is printed in reverse order
	 *  To show cards are added to the front of the list instead of the back 
	 * @param index the index that the user sees of the card wanting to be removed
	 * @return the removed card
	 */
	public Card remove (int index) 
	{
		Card temp = GY.remove(back-index);
		back--;
		return temp;
	}
	
	/**
	 * Prints the names of all of the cards in GY in reversed order
	 * @return The list of the names of the cards in GY in reversed order to look like a stack
	 */
	public String toString() 
	{
		if(GY.isEmpty())
		{
			return "[]";
		}
		String str = "["+ GY.get(back-1).getName();;
		for (int i = 2; i < GY.size()+1; i++) 
		{
			str += ", "+ GY.get(back-i).getName();
		}
		
		return str+"]";
	}
}
