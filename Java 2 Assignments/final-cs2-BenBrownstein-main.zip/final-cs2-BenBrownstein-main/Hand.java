import java.util.*;

public class Hand{
	//ArrayList of Cards
	private List<Card> hand;
	
	/**
	 * Initializes the class
	 */
	public Hand()
	{
		hand = new ArrayList<>();
	}
	
	/**
	 * Adds cards to the hand ArrayList
	 * @param card card object to be added
	 */
	public void add(Card card) 
	{
		hand.add(card);
	}
	
	/**
	 * Removes a card from the index
	 * @param index the card to be removed
	 * @return the removed card
	 */
	public Card remove(int index) 
	{
		return hand.remove(index-1);
	}
	
	/**
	 * Gets the info of a card at an index
	 * @param index the index of the card that info is needed
	 * @return the String which has the cards info
	 */
	public String getInfo(int index) 
	{
		return hand.get(index).getInfo();
	}
	
	/**
	 * Gets the name of a card at an index
	 * @param index the index of the card that name is needed
	 * @return the String which has the cards name
	 */
	public String getName(int index) 
	{
		return hand.get(index).getName();
	}
	
	/**
	 * Gets the base stats of a card at an index
	 * @param index the index of the card that base stats is needed
	 * @return the String which has the cards base stats
	 */
	public String getBaseStats(int index) 
	{
		return hand.get(index).getBaseStats();
	}
	
	/**
	 * Prints the name of all cards in the hand
	 * @return the String with the names of all cards in the hand
	 */
	public String toString() 
	{
		if(hand.isEmpty())
		{
			return "[]";
		}
		String str = "["+ hand.get(0).getName();;
		for (int i = 1; i < hand.size(); i++) 
		{
			str += ", "+ hand.get(i).getName();
		}
		
		return str+"]";
	}
	
	/**
	 * Shuffles the cards in the hand
	 */
	public void shuffle() 
	{
		Collections.shuffle(hand);
	}
}
