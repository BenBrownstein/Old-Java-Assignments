
public class MCards extends Card{
	//The ATK stat printed on the card
	private int baseATK;
	//The DEF stat printed on the card
	private int baseDEF;
	//ATK modifiers that only last one turn
	private int tempATK1T;
	//DEF modifiers that only last one turn
	private int tempDEF1T;
	//ATK modifiers that last until a condition is met like the card giving the bonus getting destroyed or the effect giving the bonus is no longer doing so
	private int tempATKCont;
	//DEF modifiers that last until a condition is met like the card giving the bonus getting destroyed or the effect giving the bonus is no longer doing so
	private int tempDEFCont;
	//Used to see if the monsters is an effect monster 
	//I am using an int instead of a boolean as when I was doing the boolean when testing the boolean was randomly becoming true when it should be false
	private int isEffect;
	//The text that is on the card either flavor text or the effect
	private String cText;
	//The attribute of the monster
	private String attri;
	//The type of monster the card is like Dragon or Spellcaster
	private String type;
	//The name of the monster
	private String name;
	//The level of the monster 
	private int level;
	//String which tells the commands to use the effect
	private String effectUsage;
	//Indicates what position the monster is in 1 being ATK, 2 being set DEF, and 3 being faceup DEF
	private int position;
	/**
	 * Initializing the class
	 */
	public MCards() 
	{
		baseATK = -1;
		baseDEF = -1;
		tempATK1T = 0;
		tempDEF1T = 0;
		tempATKCont = 0;
		tempDEFCont = 0;
		isEffect = 0;
		cText = null;
		attri = null;
		type = null;
		name = null;
		level = -1;
		effectUsage = null;
		position = 0;
	}

	/**
	 * Initializing the class with the name of the card
	 * @param name the name of the card
	 */
	public MCards(String name) 
	{
		baseATK = -1;
		baseDEF = -1;
		tempATK1T = 0;
		tempDEF1T = 0;
		tempATKCont = 0;
		tempDEFCont = 0;
		isEffect = 0;
		cText = null;
		attri = null;
		type = null;
		this.name = name;
		level = -1;
		effectUsage = null;
		position = 0;
	}
	
	/**
	 * Setter for a monsters base attack stat
	 * @param ATK the attack of the monster
	 */
	public void setBaseATK(int baseATK) 
	{
		this.baseATK = baseATK;
	}
	
	/**
	 * Getter for a monsters base attack stat
	 * @return returns base attack
	 */
	public int getBaseATK () 
	{
		return baseATK;
	}
	
	/**
	 * Setter for a monsters base defense stat
	 * @param DEF the defense of the monster
	 */
	public void setBaseDEF(int baseDEF) 
	{
		this.baseDEF = baseDEF;
	}
	
	/**
	 * Getter for a monsters base defense stat
	 * @return returns base defense
	 */
	public int getBaseDEF () 
	{
		return baseDEF;
	}
	
	/**
	 * Gets the attack and defense of a monster and prints them in a formatted way
	 * @return the formated attack and defense
	 */
	public String getBaseStats()
	{
		if (baseATK == -1 || baseDEF == -1) 
		{
			throw new IllegalArgumentException ("The card is not complete");
		}
		String formating = "ATK " + baseATK + "/DEF " + baseDEF;
		return formating;
	}
	
	/**
	 * Adds the temp ATK to the temp ATK already existing that is only for this turn
	 * @param ATK the monster is gaining
	 */
	public void addTempATK1T(int tempATK) 
	{
		tempATK1T = tempATK1T + tempATK;
	}
	
	/**
	 * Getter for a monsters temp ATK that lasts for one turn
	 * @return returns temp ATK that lasts for one turn
	 */
	public int getTempATK1T () 
	{
		return tempATK1T;
	}
	
	/**
	 * Adds the temp DEF to the temp DEF already existing that is only for this turn
	 * @param DEF the monster is gaining
	 */
	public void addTempDEF1T(int tempDEF) 
	{
		tempDEF1T = tempDEF1T + tempDEF;
	}
	
	/**
	 * Getter for a monsters temp DEF that lasts for one turn
	 * @return returns temp DEF that lasts for one turn
	 */
	public int getTempDEF1T () 
	{
		return tempDEF1T;
	}
	
	/**
	 * Adds the temp ATK to the temp ATK already existing that lasts until the condition that added it is stopped
	 * @param ATK the monster is gaining
	 */
	public void addTempATKCont(int tempATK) 
	{
		tempATKCont = tempATKCont + tempATK;
	}
	
	/**
	 * Getter for a monsters base attack stat
	 * @return returns base attack
	 */
	public int getTempATKCont () 
	{
		return tempATKCont;
	}
	
	/**
	 * Adds the temp DEF to the temp DEF already existing that lasts until the condition that added it is stopped
	 * @param DEF the monster is gaining
	 */
	public void addTempDEFCont(int tempDEF) 
	{
		tempDEFCont = tempDEFCont + tempDEF;
	}
	
	/**
	 * Getter for a monsters temp DEF that lasts until the condition that added it is stopped
	 * @return returns temp DEF that lasts until the condition that added it is stopped
	 */
	public int getTempDEFCont () 
	{
		return tempDEFCont;
	}
	
	/**
	 * Gets both kinds temp ATK and DEF of a monster
	 * Adds tempATK1T with tempATKCont and adds tempDEF1T with tempDEFCont
	 * Prints the total in a formatted way
	 * @return the formated temp attack and defense
	 */
	public String getTempStats()
	{
		int ATK = tempATK1T + tempATKCont;
		int DEF = tempDEF1T + tempDEFCont;
		String formating = "ATK " + ATK + "/DEF " + DEF;
		return formating;
	}
	
	/**
	 * Getter for the current ATK of a monster
	 * Current is base plus any modifiers
	 * @return the current ATK of a monster
	 */
	public int getCurrentATK() 
	{
		int ATK = baseATK + tempATK1T + tempATKCont;
		return ATK;
	}
	
	/**
	 * Getter for the current DEF of a monster
	 * Current is base plus any modifiers
	 * @return the current DEF of a monster
	 */
	public int getCurrentDEF() 
	{
		int DEF = baseDEF + tempDEF1T + tempDEFCont;
		return DEF;
	}
	/**
	 * Gets the base ATK and DEF and both kinds temp ATK and DEF of a monster
	 * Adds baseATK with tempATK1T and tempATKCont and adds baseDEF with tempDEF1T and tempDEFCont
	 * Prints the total in a formatted way
	 * @return the formated current attack and defense
	 */
	public String getCurrentStats() 
	{
		if (baseATK == -1 || baseDEF == -1) 
		{
			throw new IllegalArgumentException ("The card is not complete");
		}
		int ATK = baseATK + tempATK1T + tempATKCont;
		int DEF = baseDEF + tempDEF1T + tempDEFCont;
		String formating = "ATK " + ATK + "/DEF " + DEF;
		return formating;
	}
	
	/**
	 * Sets isEffect to 1 signifying that the monster is an effect monster
	 */
	public void isEffect () 
	{
		isEffect = 1;
	}
	
	/**
	 * Sets isEffect to 0 signifying that the monster is an normal monster with no effect
	 */
	public void isNormal () 
	{
		isEffect = 0;
	}
	
	/**
	 * Gets if the monster is an effect monster or a normal monster
	 * @return if the monster is an effect monster or a normal monster
	 */
	public String getIsEffect() 
	{
		if (isEffect == 1) 
		{
			return "Effect";
		}
		return "Normal";
	}
	
	/**
	 * Sets the text that is on the card if the text is in "" then the monster is a normal monster if not then it is an effect monster
	 * @param cText The text being added to the card
	 */
	public void setCText (String cText) 
	{
		this.cText = cText;
	}
	
	/**
	 * Getter for the cText
	 * @return The text on the monster card
	 */
	public String getCText() 
	{
		return cText;
	}
	
	/**
	 * Setter for the attribute of the monster
	 * @param attri the attribute of the monster (Dark, Light, Fire, Water, Earth, Wind, and Divine)
	 */
	public void setAttri (String attri) 
	{
		this.attri = attri;
	}
	
	/**
	 * Getter for the attribute of the monster
	 * @return the attribute of that monster
	 */
	public String getAttri() 
	{
		return attri;
	}
	
	/**
	 * Setter for the type of a monster card
	 * @param the type of the monster
	 */
	public void setType (String type) 
	{
		this.type = type;
	}
	
	/**
	 * Getter for the type of a monster card
	 * @return the type of the monster card
	 */
	public String getType() 
	{
		return type;
	}
	/**
	 * Setter for the name of the monster
	 * @param name the name of the monster card
	 */
	public void setName (String name) 
	{
		this.name = name;
	}
	
	/**
	 * Getter for the name of the monster
	 * @return the name of the monster card
	 */
	public String getName() 
	{
		return name;
	}
	
	/**
	 * Setter for the level of a monster 1-12
	 * @param level the level of the monster
	 */
	public void setLevel(int level) 
	{
		this.level = level;
	}
	
	/**
	 * Getter for the level of a monster
	 * @return the level of a monster
	 */
	public int getLevel() 
	{
		return level;
	}
	
	/**
	 * Setter for the effect usage of a monster
	 * @param effectUsage how to use the effect of a monster
	 */
	public void setEffectUsage (String effectUsage) 
	{

		this.effectUsage = effectUsage;
	}
	
	/**
	 * Getter for effectUsage will return a string that there is no effect if the monster is a normal monster based on isEffect
	 * @return returns the effect usage of a monster
	 */
	public String getEffectUsage() 
	{
		if (isEffect == 0) 
		{
			return "The monster is not an effect Monster";
		}
		return effectUsage;
	}
	/**
	 * Sets what position on the field a monster is in
	 * @param position an int that signifies a position on the field
	 */
	public void setPosition(int position) 
	{
		this.position = position;
	}
	
	/**
	 * Returns a String that tells the user what position the monster is in
	 * @return the position the monster on the field is in
	 */
	public String getPosition() 
	{
		if (position == 1) 
		{
			return "ATK mode";
		}
		if (position == 2) 
		{
			return "Set";
		}
		if (position == 3) 
		{
			return "Faceup DEF mode";
		}
		return "This card is not on the field";
	}
	/**
	 * Prints all of the parts of a monster card in a formatted way
	 * @return the string with all of the data in the class except usage formatted
	 */
	public String getInfo() 
	{
		if (baseATK == -1 || baseDEF == -1 || cText == null || attri == null || type == null || name == null || level == -1) 
		{
			throw new IllegalArgumentException ("The card is not complete");
		}
		String info = name + "\nAttribute: " + attri + "\nLevel: " + level + "\nType: " + type + "\n";
		if (isEffect == 1) 
		{
			info = info + "Effect";
		} else 
		{
			info = info + "Normal";
		}
		int totalATK = baseATK + tempATK1T + tempATKCont;
		int totalDEF = baseDEF + tempDEF1T + tempDEFCont;
		info = info + "\n" + cText + "\nBase Stats: \nATK " + baseATK + "/DEF " + baseDEF;
		info = info + "\nCurrent Stats: \nATK " + totalATK + "/DEF " + totalDEF;
		return info;
	}
	
}
