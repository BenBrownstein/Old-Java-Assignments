
public class TCards  extends Card{
	//The name of the card
	private String name;
	//The effect of the card
	private String effect;
	//The subType of the card as in Normal, Counter, or Continuous
	private String subType;
	//String which tells the commands to use the effect
	private String effectUsage;
	//If the card was set this turn
	private boolean turnSet;
	//If this card is set
	private boolean set;
	
	/**
	 * Initializing the class
	 */
	public TCards() 
	{
	name = null;
	effect = null;
	subType = null;
	effectUsage = null;
	turnSet = true;
	set = false;
	}
	
	/**
	 * Initializing the class with the name of the card
	 * @param name the name of the card
	 */
	public TCards(String name) 
	{
	this.name = name;
	effect = null;
	subType = null;
	effectUsage = null;
	turnSet = true;
	set = false;
	}
	
	/**
	 * Setter for the name of the trap
	 * @param name the name of the trap card
	 */
	public void setName (String name) 
	{
		this.name = name;
	}
	
	/**
	 * Getter for the name of the trap
	 * @return the name of the trap card
	 */
	public String getName() 
	{
		return name;
	}
	
	/**
	 * Sets the effect
	 * @param effect The effect of the spell card
	 */
	public void setEffect (String effect) 
	{
		this.effect = effect;
	}
	
	/**
	 * Getter for the effect
	 * @return The effect of the spell card
	 */
	public String getEffect() 
	{
		return effect;
	}
	
	/**
	 * Setter for the sub type of a trap card
	 * @param the sub type of the trap
	 */
	public void setSubType (String subType) 
	{
		this.subType = subType;
	}
	
	/**
	 * Getter for the sub type of a trap card
	 * @return the sub type of the trap card
	 */
	public String getSubType() 
	{
		return subType;
	}
	
	/**
	 * Setter for the effect usage of a trap
	 * @param effectUsage how to use the effect of a trap
	 */
	public void setEffectUsage (String effectUsage) 
	{

		this.effectUsage = effectUsage;
	}
	
	/**
	 * Getter for effectUsage
	 * @return returns the effect usage of a trap
	 */
	public String getEffectUsage() 
	{
		return effectUsage;
	}
	
	/**
	 * Sets turnSet to true to signify a new turn
	 */
	public void set() 
	{
		set = true;
	}
	
	/**
	 * To see if it is possible to activate the card and will return the effect if it can be activated
	 * @return The effect of the trap
	 */
	public void activate() 
	{
		set = false;
	}
	
	/**
	 * Getter for if the card is set
	 * @return if the card is set or not
	 */
	public boolean getSet() 
	{
		return set;
	}
	
	/**
	 * Prints all of the parts of a monster card in a formatted way
	 * @return the string with all of the data in the class except usage formatted
	 */
	public String getInfo() 
	{
		String info = name + "\nType: " + subType + " Trap \n" + effect;
		return info;
	}
}
